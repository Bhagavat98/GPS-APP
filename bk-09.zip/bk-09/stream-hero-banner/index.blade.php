@extends('layouts.main')
@section('content')
<style>
</style>
<!-- @section('vendor-style')
@endsection -->
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row ">
                
                </div>
            </div><!-- /.container-fluid -->
        </section>
  <!-- Content Header (Page header) -->

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header pb-1">
              <h3 class="card-title" style="font-size:20px;"><b>{{ $pageTitle }}</b></h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-primary" id="addNewButton" data-toggle="modal" data-target="#modalStreamHeroBannerFrom">
                    <i class="fas fa-plus">&nbsp;Add New</i>
                    </button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive">
                <table id="streamHeroBannerTable" class="display nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Media</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Sequence</th>
                            <th>Last updated by</th>
                            <th>Status</th>
                            <th>Actions</th>
                            <th>Updated at</th>
                        </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
  
    <!-- modal Create New Stream Hero Banner  -->
        <div class="modal fade" id="modalStreamHeroBannerFrom"  data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form id="createNewStreamHeroBannerFrom" class="createNewStreamHeroBannerFrom">
                        @csrf
                        <div class="modal-header">
                            <h4 class="modal-title">Create New Stream Hero Banner</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div><!-- /.modal-header -->
                        <div class="modal-body">
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title" required>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" rows="3" id="description" name="description" placeholder="Enter Description...">{{ old('description') }}</textarea>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Sequence</label>
                                        <input type="number" class="form-control" id="sequence" name="sequence" placeholder="Enter sequence no." required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select class="form-control" id="select2Status" style="width: 100%;" name="status" required>
                                            <option></option>
                                            <option value="1">Enable</option>
                                            <option value="0">Disable</option>
                                        </select>
                                    </div>
                                </div>

                                <fieldset class="border p-2">
                                    <legend  class="legendTxt float-none w-auto">Upload Media</legend>
                                    <div class="col-md-12">
                                        <input type="file" style="visibility:hidden" name="image_upload" id="imgInpFile"  accept="image/*">
                                        <input type="file" style="visibility:hidden" name="video_upload" id="vidInpFile"  accept="video/*">
                                        <div class="btn-group w-100">
                                            <button type="button" id="uploadImageBtn" class="btn btn-success col ">
                                                <i class="fas fa-image"></i>
                                                <span>Upload image</span>
                                            </button>
                                            <button type="button" id="uploadVideoBtn" class="btn btn-primary col ">
                                                <i class="fas fa-camera"></i>
                                                <span>Upload video</span>
                                            </button>
                                            <button type="button" id="resetbtn" class="btn btn-warning col ">
                                                <i class="fas fa-times-circle"></i>
                                                <span>Cancel upload</span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="row col-sm-12 pt-2">
                                        <div class="position-relative p-3" id="prviewImageDiv">
                                            <img style="visibility:hidden"  id="prviewImage" src="" data-dz-thumbnail/>
                                        </div>
                                        <video id="prviewVideo" style="visibility:hidden" width="20" height="20" controls>
                                            Your browser does not support the video tag.
                                        </video>
                                    </div>
                                </fieldset>

                            </div><!-- row end -->
                        </div><!-- /.modal-body -->
                        <div class="modal-footer justify-content-center">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="reset" id="addResetbtn" class="btn btn-warning">Reset</button>
                            <button type="submit" id="btnSubmit" class="btn btn-primary">Submit</button>
                        </div><!-- /.modal-footer -->
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <!-- modal Create New Stream Hero Banner /. -->

    <!-- modal update New Stream Hero Banner -->
        <div class="modal fade" id="modalUpdateStreamHeroBanner"  data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form id="updateStreamHeroBannerFrom" class="updateStreamHeroBannerFrom">
                        @csrf
                        <input type="hidden" class="form-control" id="updateUid" name="id" required>
                        <div class="modal-header">
                            <h4 class="modal-title">Update Stream Hero Banner</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div><!-- /.modal-header -->
                        <div class="modal-body">
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control" id="updateTitle" name="title" placeholder="Enter Title" required>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" rows="3" id="updateDescription" name="description" placeholder="Enter Description..."></textarea>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Sequence</label>
                                        <input type="number" class="form-control" id="updateSequence" name="sequence" placeholder="Enter sequence no." required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select class="form-control" id="updateSelect2Status" style="width: 100%;" name="status" required>
                                            <option></option>
                                            <option value="1">Enable</option>
                                            <option value="0">Disable</option>
                                        </select>
                                    </div>
                                </div>

                                <fieldset class="border p-2">
                                    <legend  class="legendTxt float-none w-auto">Upload Media</legend>
                                    <div class="col-md-12">
                                        <input type="file" style="visibility:hidden" name="image_upload" id="updateImgInpFile"  accept="image/*">
                                        <input type="file" style="visibility:hidden" name="video_upload" id="updateVidInpFile"  accept="video/*">
                                        <div class="btn-group w-100">
                                            <button type="button" id="updateUploadImageBtn" class="btn btn-success col ">
                                                <i class="fas fa-image"></i>
                                                <span>Upload image</span>
                                            </button>
                                            <button type="button" id="updateUploadVideoBtn" class="btn btn-primary col ">
                                                <i class="fas fa-camera"></i>
                                                <span>Upload video</span>
                                            </button>
                                            <button type="button" id="updateResetbtn" class="btn btn-warning col ">
                                                <i class="fas fa-times-circle"></i>
                                                <span>Cancel upload</span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="row col-sm-12 pt-2">
                                        <div class="position-relative p-3" id="updatePrviewImageDiv">
                                            <img style="visibility:hidden"  id="updatePrviewImage" src="" data-dz-thumbnail/>
                                        </div>
                                        <video id="updatePrviewVideo" style="visibility:hidden" width="20" height="20" controls>
                                            Your browser does not support the video tag.
                                        </video>
                                    </div>
                                </fieldset>
                            </div><!-- row end -->
                        </div><!-- /.modal-body -->
                        <div class="modal-footer justify-content-center">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="reset" id="updateBtnReset" class="btn btn-warning">Reset</button>
                            <button type="submit" id="updateBtnSubmit" class="btn btn-primary">Submit</button>
                        </div><!-- /.modal-footer -->
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <!-- modal update New Stream Hero Banner /. -->

</div>
<!-- /.content-wrapper -->
@section('page-scripts')
<script>
$(document).ready(function(){

/*--------------- javascript script  ---------------*/
    // select status
    $("#select2Status").select2({
        placeholder: "Select a Status",
        allowClear: true
    });
    //update select 2 status
    $("#updateSelect2Status").select2({
        placeholder: "Select a Status",
        allowClear: true
    });
    // form reset
    $("#createNewStreamHeroBannerFrom").trigger("reset");
    // add new button
    $('#addNewButton').on('click', function(e) {
        document.getElementById('resetbtn').click();
        document.getElementById('addResetbtn').click();
        $("#select2Status").val('');
        $("#select2Status").trigger("change");
    });
/*--------------- javascript script  ---------------*/

/*--------------- upload media ---------------*/
        // upload Image Btn click 
        $('#uploadImageBtn').on('click', function(e) {
            document.getElementById('resetbtn').click();
            document.getElementById('imgInpFile').click();
        });
        // upload video Btn click
        $('#uploadVideoBtn').on('click', function(e) {
            document.getElementById('resetbtn').click();
            document.getElementById('vidInpFile').click();
        });

        //reset Image click
        $('#resetbtn').on('click', function(e) {
            //image scr and image file rest
            $("#imgInpFile").val("");
            $("#prviewImage").attr("src", "");
            prviewImage.style.visibility = 'hidden';
            $("#prviewImageDiv img").css({'height' : '0px'});

            //video scr and video file rest
            $("#vidInpFile").val("");
            $("#prviewVideo").attr("src", "");
            prviewVideo.style.visibility = 'hidden';
            //prviewVideo.style.display='none';
            $("#prviewVideo").attr('width','20');
            $("#prviewVideo").attr('height','20');
        });


        // Image input file onchange
        imgInpFile.onchange = evt => {
            const [file] = imgInpFile.files
            if (file) {
                $("#prviewImageDiv img").css({'height' : '140px'});
                prviewImage.style.visibility = 'visible';
                prviewImage.src = URL.createObjectURL(file)
            }
        }
        // Video input file onchange
        vidInpFile.onchange = evt => {
            const [file] = vidInpFile.files
            if (file) {
                $("#prviewVideo").attr('width','320');
                $("#prviewVideo").attr('height','240');
                prviewVideo.style.visibility = 'visible';
                prviewVideo.src = URL.createObjectURL(file);
            }
        }
/*--------------- upload media end ---------------*/

/*--------------------- update upload media -------------------*/
        // update upload image btn click
        $('#updateUploadImageBtn').on('click', function(e) {
            document.getElementById('updateResetbtn').click();
            document.getElementById('updateImgInpFile').click();
        });
        // upload video Btn click
        $('#updateUploadVideoBtn').on('click', function(e) {
            document.getElementById('updateResetbtn').click();
            document.getElementById('updateVidInpFile').click();
        });
        //update reset btn click
        $('#updateResetbtn').on('click', function(e) {
            //image scr and image file rest
            $("#updateImgInpFile").val("");
            $("#updatePrviewImage").attr("src", "");
            updatePrviewImage.style.visibility = 'hidden';
            $("#updatePrviewImageDiv img").css({'height' : '0px'});

            //video scr and video file rest
            $("#updateVidInpFile").val("");
            $("#updatePrviewVideo").attr("src", "");
            updatePrviewVideo.style.visibility = 'hidden';
            $("#updatePrviewVideo").attr('width','20');
            $("#updatePrviewVideo").attr('height','20');
        });
        // Image input file onchange
        updateImgInpFile.onchange = evt => {
            const [file] = updateImgInpFile.files
            if (file) {
                $("#updatePrviewImageDiv img").css({'height' : '140px'});
                updatePrviewImage.style.visibility = 'visible';
                updatePrviewImage.src = URL.createObjectURL(file)
            }
        }
        // Video input file onchange
        updateVidInpFile.onchange = evt => {
            const [file] = updateVidInpFile.files
            if (file) {
                $("#updatePrviewVideo").attr('width','320');
                $("#updatePrviewVideo").attr('height','240');
                updatePrviewVideo.style.visibility = 'visible';
                updatePrviewVideo.src = URL.createObjectURL(file);
            }
        }
/*--------------------- update upload media end -------------------*/

/*--------------- DataTable ---------------*/
    DataTable();
    function DataTable() {
       $title = "Stream Hero Banner List";
        // Datatable defination
        $DataTable = $("#streamHeroBannerTable").DataTable({
            ajax: "{{ route('streamHeroBanner.index') }}?type=1", //Ajax call, it will only work if ajax will return the
            // data in the format of json ex;- {"data":[{"key1":"val1","key2":"val2,....}]},
            info: false,
            autoWidth: false,
            paging: true, // paging is set to false
            columns: [
                //filling the tbody with json data
                {
                    data: null
                },
                {
                    data: null,
                    render: function (data) {
                        if(data.media_type == "0"){
                            return '<img src="'+data.media_url+'" class="img-fluid img-thumbnail" style="max-height: 100px;" alt="'+data.media_url+'">';
                        }else if(data.media_type == "1"){
                            return  '<video width="180" height="100"  controls>'+
                                        '<source src="'+data.media_url+'" type="video/mp4">Your browser does not support the video tag.'+
                                    '</video>';
                        }else{
                            return '<span class="badge badge-secondary">NA</span>';
                        } 
                    }
                },
                {
                    data: "title"
                },
                {
                    data: "description"
                },
                {
                    data: "sequence"
                },
                {
                    data: "last_updated_by"
                },
                {
                    data: null,
                    render: function (data) {
                        if(data.status == "1"){
                            return '<span class="badge badge-success">Enable</span>';
                        }else if(data.status == "0"){
                            return '<span class="badge badge-danger">Disable</span>';
                        }else{
                            return '<span class="badge badge-secondary">NA</span>';
                        } 
                    }
                },
                {
                    data: null,
                    render: function (data) {
                        //Edit and Delete button added if data is found
                        return  '<i class="fa fa-edit btn_icon_edit" ></i>&nbsp;&nbsp;'+
                        '<i class="fas fa-trash-alt delete_btn" id="'+data._id+'"></i>';
                    }
                },
                {
                    data: "updated_at"
                }
            ],
            "columnDefs": [{
                // disabling ordering and searching false for action column
                //"targets": ,
                "searchable": false,
                "orderable": false
            }],
            sAjaxDataProp: "data",
            "language": { 
                "emptyTable": "Stream Hero Banner"
            }
        });
        $DataTable.on('order.dt search.dt', function () {
            $DataTable.column(0, {
                search: 'applied',
                order: 'applied'
            }).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        }).draw();
    }
/*--------------- DataTable end -----------------*/

/*--------------- Create New  -----------------*/
    $("#createNewStreamHeroBannerFrom").on("submit", function (e) {
        e.preventDefault();
        $type = 'red';
        $icon = 'fa fa-times'
        // new staff ajax call
        $.ajax({
            url: "{{ route("streamHeroBanner.create") }}",
            type: "POST",
            dataType: "json",
            contentType: false,
            processData: false,
            data: new FormData(this),
            success: function ($data) {
                if ($data.status === true) {
                    $("#modalStreamHeroBannerFrom").modal('hide');
                    $("#createNewStreamHeroBannerFrom").trigger("reset");
                    $('#streamHeroBannerTable').DataTable().ajax.reload(null, false);
                    $type = 'green';
                    $icon = 'fa fa-check';
                }
                $.alert({
                    // Jquery confirm will display result after ajax
                    title: "Create Stream Hero Banner",
                    icon: $icon,
                    content: $data.message,
                    type: $type
                });
                document.getElementById('addResetbtn').click();
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                $.alert({
                    // Jquery confirm will display result after ajax
                    title: "Create Stream Hero Banner",
                    icon: "fa fa-times",
                    content: msg,
                    type: "red"
                });
            }
        });
    });
/*--------------- create New end -----------------*/

/*--------------- From validate -----------------*/
    $('#createNewStreamHeroBannerFrom, #updateStreamHeroBannerFrom').validate({
        rules: {
            title: {
                required: true,
            },
            description: {
                required: true,
            },
            status: {
                required: true,
            },
            sequence: {
                required: true,
            }
        },
        errorElement: 'span',
        errorPlacement: function(error, element) {
            error.addClass('invalid-feedback');
            element.closest('.form-group').append(error);
        },
        highlight: function(element, errorClass, validClass) {
            $(element).addClass('is-invalid');
        },
        unhighlight: function(element, errorClass, validClass) {
            $(element).removeClass('is-invalid');
        }
    });
/*--------------- From validate end -----------------*/

/*--------------- update btn click -----------------*/
    $("#streamHeroBannerTable tbody").on("click", '.btn_icon_edit', function () {
        $("#updateStreamHeroBannerFrom").trigger("reset");
        document.getElementById('updateResetbtn').click();
        var data = $("#streamHeroBannerTable").DataTable().row($(this).parents('tr')).data();
        console.log(data);
        $("#updateUid").val(data['_id']);
        $("#updateTitle").val(data['title']);
        $("#updateDescription").val(data['description']);
        $("#updateSequence").val(data['sequence']);
        $("#updateSelect2Status").val(data['status']);
        $("#updateSelect2Status").trigger("change");
        // thumbnail image url
        if(data["thumbnail_image_url"]){
            $("#updatePrviewImageDiv img").css({'height' : '140px'});
            updatePrviewImage.style.visibility = 'visible';
            updatePrviewImage.src = data["thumbnail_image_url"];
        }
        // image / video privew
        if(data["media_type"] == "0"){
            $("#updatePrviewImageDiv img").css({'height' : '140px'});
            updatePrviewImage.style.visibility = 'visible';
            updatePrviewImage.src = data["media_url"];
        }else if(data["media_type"] == "1"){
            $("#updatePrviewVideo").attr('width','320');
            $("#updatePrviewVideo").attr('height','240');
            updatePrviewVideo.style.visibility = 'visible';
            updatePrviewVideo.src = data["media_url"];       
        }else{
        }
        $("#modalUpdateStreamHeroBanner").modal('show');
    });
/*--------------- update btn click /. -----------------*/

/*--------------- update form submit  -----------------*/
    $("#updateStreamHeroBannerFrom").on("submit", function (e) {
        e.preventDefault();
        $type = 'red';
        $icon = 'fa fa-times'
        // new staff ajax call
        $.ajax({
            url: "{{ route("streamHeroBanner.update") }}",
            type: "POST",
            dataType: "json",
            contentType: false,
            processData: false,
            data: new FormData(this),
            success: function ($data) {
                if ($data.status === true) {
                    $("#modalUpdateStreamHeroBanner").modal('hide');
                    $('#streamHeroBannerTable').DataTable().ajax.reload(null, false);
                    $type = 'green';
                    $icon = 'fa fa-check';
                    document.getElementById('updateBtnReset').click();
                }
                $.alert({
                    // Jquery confirm will display result after ajax
                    title: "Update Stream Hero Banner",
                    icon: $icon,
                    content: $data.message,
                    type: $type
                });
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                $.alert({
                    // Jquery confirm will display result after ajax
                    title: "Update Stream Hero Banner",
                    icon: "fa fa-times",
                    content: msg,
                    type: "red"
                });
            }
        });
    });
/*--------------- update form submit end -----------------*/

/*--------------- Delete  -----------------*/
    // assigning onclick event for delete button
    $("#streamHeroBannerTable tbody").on("click", '.delete_btn', function () {
        var data = $("#streamHeroBannerTable").DataTable().row($(this).parents('tr')).data();
        $.confirm({
            title: "Delete Stream Hero Banner",
            type: "red",
            icon: "fa fa-trash",
            content: "are you sure to Delete this Stream Hero Banner ?",
            buttons: {
                Yes: {
                    btnClass: "btn-red",
                    action: function () {
                        delete_table(data['_id']);
                    },
                },
                No: function () {
                    // Nothing will happen after clicking no
                }
            }
        })
    });

    function delete_table(uid) {
        console.log("delete_table()->>"+uid);
        var token = "{{ csrf_token() }}";
        $type = "red";
        $icon = "fa fa-times";
        $.ajax({
            url: "{{ route('streamHeroBanner.delete') }}",
            type: "POST",
            dataType: "json", //the output of ajax will parsed to json
            data: { //passing data to ajax
                "uid": uid,
                "_token":token
            },
            success: function ($data) {
                //$data contains the
                if ($data.status === true) {
                    $('#streamHeroBannerTable').DataTable().ajax.reload(null, false);
                    //DataTable();
                    $type = "green";
                    $icon = "fa fa-check";
                }
                // If delete is success
                $.alert({
                    icon: $icon,
                    type: $type,
                    title: "Delete Stream Hero Banner",
                    content: $data.message
                });
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                $.alert({
                    // Jquery confirm will display result after ajax
                    title: "Delete Stream Hero Banner",
                    icon: "fa fa-times",
                    content: msg,
                    type: "red"
                });
            }
        });
    }
/*--------------- Delete end -----------------*/

});
</script>
@stop
@endsection