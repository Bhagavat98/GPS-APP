<?php

namespace App\Http\Controllers\MobCMS;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use App\Models\MobCMS\AboutClubMahindra;
use App\Models\MobCMS\CardTitleAndSubTitle;
use Auth;
use Log;
use DB;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Common;
use Illuminate\Support\Str;

class AboutClubMahindraController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    } 
    /*
     * Function index
     * @access  Public
     * @package About Club Mahindra Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function index(Request $request) {
        try{
            $log_data = $data = [];
            $log_data['function'] = 'index()';
            $log_data['request->all'] = $request->all();
            if($request->type  ==  "1"){
                $participateNowData = AboutClubMahindra::all();
                foreach ($participateNowData as $value) {
                    $data['data'][] = array(
                        '_id' => $value->_id,
                        'thumbnail_image_url'=>$value->thumbnail_image_url,
                        'thumbnail_file_path'=>$value->thumbnail_file_path,
                        'video_link' => $value->video_link,
                        'media_url' => $value->media_url,
                        'media_type' => $value->media_type,
                        'file_path' => $value->file_path,
                        'media_overlay_text' => $value->media_overlay_text,
                        'sequence' => $value->sequence,
                        'status' => $value->status,
                        'last_updated_by' => $value->last_updated_by,
                        'created_at' => date("d-M-Y",strtotime($value->created_at)),
                        'updated_at' => date("d-M-Y",strtotime($value->updated_at)),
                    );
                }
                $log_data["participateNowDataCount"] = count($data);
                if(!empty($data)  &&  isset($data)  &&  count($data)  >  0) { 
                    echo json_encode($data);exit;
                }else{
                    echo "{\"data\":[]}";exit;
                }
                
            }
            // get card title and sub title
            $cardTitleAndSubTitleData = CardTitleAndSubTitle::where("card_name","about-club-mahindra")
            ->first();
            // title
            if(!empty($cardTitleAndSubTitleData->title)  &&  isset($cardTitleAndSubTitleData->title)){
                $pageTitle = $cardTitleAndSubTitleData->title;
            }else{
                $pageTitle = "About Club Mahindra";
            }
            // sub title
            if(!empty($cardTitleAndSubTitleData->sub_title)  &&  isset($cardTitleAndSubTitleData->sub_title)){
                $pageSubTitle = $cardTitleAndSubTitleData->sub_title;
            }else{
                $pageSubTitle = "Legacy of 20 years and counting";
            }
            $log_data["pageTitle"] = $pageTitle;
            $log_data["pageSubTitle"] = $pageSubTitle;
            Log::info($log_data);
            return view('MobCMS/about-club-mahindra/index',compact('pageTitle','pageSubTitle'));
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | index()';
            Log::info($log_data);
            if($request->type  ==  "1"){
                echo "{\"data\":[]}";exit;
            }else{
                $msg = array('message' => Config::get('constants.mob_cms.server_error_500'),'alert-type' => 'error');
                return redirect('/home')->with($msg);
            }
        }
    }

    /**
     * Function create
     * @access  Public
     * @package About Club Mahindra Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function create(Request $request) {
        try{
            $log_data = $result = [];
            $log_data['function'] = 'create()';
            $log_data['request->all'] = $request->all();
            $validator = Validator::make($request->all(), [
                'status' => 'required|integer|between:0,5',
                'sequence' => 'required|integer|between:1,1000',
            ]);
            if($validator->fails()) {
                $result['status'] = false;
                $result['message'] = Common::validationErrorsToString($validator->errors());
                Log::info($log_data);
                return response()->json($result);
            }
            if($request->hasFile('image_upload')) {
                $log_data["mediaType"] = $mediaType = 0;
                $mediaName = Str::random(5).time().'.'. $request->image_upload->getClientOriginalExtension();
                $request->image_upload->move((Config::get('constants.module_key.image_upload_path'). '/MobCMS/images'), $mediaName);
                $mediaImgUrl = url("/")."/".Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
                $fileImgPath = Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
            }else{
                $result['status'] = false;
                $result['message'] = "thumbnail Image is required";
                Log::info($log_data);
                return response()->json($result);
            }
            
            if($request->video_upload){
                $log_data["mediaType"] = $mediaType = 1;
                $mediaName = Str::random(5).time().'.'. $request->video_upload->getClientOriginalExtension();
                $request->video_upload->move((Config::get('constants.module_key.image_upload_path'). '/MobCMS/videos'), $mediaName);
                $mediaVideoUrl = url("/")."/".Config::get('constants.module_key.image_upload_path'). '/MobCMS/videos/'.$mediaName;
                $fileVideoPath = Config::get('constants.module_key.image_upload_path'). '/MobCMS/videos/'.$mediaName;
            }else if(!empty($request->video_link)  &&  isset($request->video_link)) {
                $mediaVideoUrl = $request->video_link;
                $fileVideoPath = '';
            }else{
                $result['status'] = false;
                $result['message'] = "Video is required";
                Log::info($log_data);
                return response()->json($result);
            }
            $log_data["last_updated_by"] = $last_updated_by = Auth::user()->name;
            $insertedData = array(
                'thumbnail_image_url'=>$mediaImgUrl,
                'thumbnail_file_path'=>$fileImgPath,
                'media_type'=>1,
                'video_link'=>$request->video_link,
                'media_url'=>$mediaVideoUrl,
                'file_path'=>$fileVideoPath,
                'media_overlay_text'=>$request['media_overlay_text'],
                'sequence'=>$request['sequence'],
                'status'=>$request['status'],
                'last_updated_by'=>isset($last_updated_by) ? $last_updated_by : 0,
                'created_at'=>date("Y-m-d H:i:s"),
                'updated_at'=>date("Y-m-d H:i:s"),
            );
            // insert 
            $sqlInsertId = AboutClubMahindra::insertGetId($insertedData);
            $log_data["sqlInsertId"] = $sqlInsertId;
            if($sqlInsertId){
                $result['status'] = true;
                $result['message'] = "Record create successfully!";
            }else{
                $result['status'] = true;
                $result['message'] = "Something went wrong!";
            }
            $log_data['result'] = $result;
            Log::info($log_data);
            return response()->json($result);
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | create()';
            $result['status'] = false;
            $result['message'] = Config::get('constants.mob_cms.server_error_500');
            Log::info($log_data);
            return response()->json($result);
        }
    }

    /**
     * Function update
     * @access  Public
     * @package About Club Mahindra Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function update(Request $request) {
        try{
            $log_data = [];
            $log_data['function'] = 'create()';
            $log_data['request->all'] = $request->all();
            $validator = Validator::make($request->all(), [
                'id' => 'required',
                'status' => 'required|integer|between:0,5',
                'sequence' => 'required|integer|between:1,1000',
            ]);
            if($validator->fails()) {
                $result['status'] = false;
                $result['message'] = Common::validationErrorsToString($validator->errors());
                Log::info($log_data);
                return response()->json($result);
            }
            $oldData = AboutClubMahindra::where("_id",$request->id)
            ->first();
            if($request->hasFile('image_upload')) {
                $mediaName = Str::random(5).time().'.'. $request->image_upload->getClientOriginalExtension();
                $request->image_upload->move((Config::get('constants.module_key.image_upload_path'). '/MobCMS/images'), $mediaName);
                $mediaImgUrl = url("/")."/".Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
                $fileImgPath = Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
            }else{
                $mediaImgUrl = $oldData->thumbnail_image_url;
                $fileImgPath = $oldData->thumbnail_file_path;
            }
            // video upload
            if($request->video_upload){
                $log_data["mediaType"] = $mediaType = 1;
                $mediaName = Str::random(5).time().'.'. $request->video_upload->getClientOriginalExtension();
                $request->video_upload->move((Config::get('constants.module_key.image_upload_path'). '/MobCMS/videos'), $mediaName);
                $mediaVideoUrl = url("/")."/".Config::get('constants.module_key.image_upload_path'). '/MobCMS/videos/'.$mediaName;
                $fileVideoPath = Config::get('constants.module_key.image_upload_path'). '/MobCMS/videos/'.$mediaName;
            }else if(!empty($request->video_link)  &&   isset($request->video_link)){
                $mediaVideoUrl = $request->video_link;
                $fileVideoPath = $request->video_link;
            }else{
                $mediaVideoUrl = $oldData->media_url;
                $fileVideoPath = $oldData->file_path;
            }
            $last_updated_by = Auth::user()->name;
            $updateData = array(
                'thumbnail_image_url'=>$mediaImgUrl,
                'thumbnail_file_path'=>$fileImgPath,
                'media_type'=>1,
                'video_link'=>$request->video_link,
                'media_url'=>$mediaVideoUrl,
                'file_path'=>$fileVideoPath,
                'media_overlay_text'=>$request['media_overlay_text'],
                'sequence'=>$request['sequence'],
                'status'=>$request['status'],
                'last_updated_by'=>isset($last_updated_by) ? $last_updated_by : 0,
                'updated_at'=>date("Y-m-d H:i:s"),
            );
            $sqlUpdate = AboutClubMahindra::where("_id",$request['id'])
            ->update($updateData);
            $log_data["sqlUpdate"] = $sqlUpdate;
            if($sqlUpdate){
                if($oldData->file_path  !=  $fileVideoPath){
                    $log_data["fileDeleteStatus"] = Common::deleteFileIfExists($oldData->file_path);
                }
                if($oldData->thumbnail_file_path  !=  $fileImgPath){
                    $log_data["fileImageDeleteStatus"] = Common::deleteFileIfExists($oldData->thumbnail_file_path);
                }
                $result['status'] = true;
                $result['message'] = "Record update successfully!";
            }else{
                $result['status'] = true;
                $result['message'] = "Something went wrong!";
            }
            $log_data['result'] = $result;
            Log::info($log_data);
            return response()->json($result);
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | update()';
            $result['status'] = false;
            $result['message'] = Config::get('constants.mob_cms.server_error_500');
            Log::info($log_data);
            return response()->json($result);
        }
    }

    /**
     * Function delete
     * @access  Public
     * @package About Club Mahindra Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function delete(Request $request){
        try{
            $log_data = $result = [];
            $log_data['function'] = 'delete()';
            $log_data['request->all'] = $request->all();
            $validator = Validator::make($request->all(), [
                'uid' => 'required'
            ]);
            if($validator->fails()) {
                $result['status'] = false;
                $result['message'] = Common::validationErrorsToString($validator->errors());
                Log::info($log_data);
                return response()->json($result);
            }
            $filePath = AboutClubMahindra::where('_id', $request->uid)
            ->value("file_path");
            $thumbnailFilePath = AboutClubMahindra::where('_id', $request->uid)
            ->value("thumbnail_file_path");
            $deleteSql = AboutClubMahindra::where('_id', $request->uid)
            ->delete();
            $log_data['deleteSql'] = $deleteSql;
            if($deleteSql){
                if($filePath){
                    $log_data["filePathDeleteFile"] = Common::deleteFileIfExists($filePath);
                }
                if($thumbnailFilePath){
                    $log_data["thumbnailFilePathDeleteFile"] = Common::deleteFileIfExists($thumbnailFilePath);
                }
                $result['status'] = true;
                $result['message'] = "Record deleted successfully!";
            }else{
                $result['status'] = false;
                $result['message'] = "Something went wrong!";
            }
            $log_data['result'] = $result;
            Log::info($log_data);
            return response()->json($result);
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | delete()';
            $result['status'] = false;
            $result['message'] = Config::get('constants.mob_cms.server_error_500');
            Log::info($log_data);
            return response()->json($result);
        }
    }
 
}