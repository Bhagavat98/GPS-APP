<?php

namespace App\Http\Controllers\MobCMS;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use App\Models\MobCMS\StreamVideos;
use App\Models\MobCMS\StreamVideosCategory;
use Auth;
use Log;
use DB;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Common;
use Illuminate\Support\Str;

class StreamVideosController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    } 
    /*
     * Function index
     * @access  Public
     * @package Stream Videos Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function index(Request $request) {
        try{
            $log_data = $data = [];
            $log_data['function'] = 'index()';
            $log_data['request->all'] = $request->all();
            if($request->type  ==  "1"){
                if(!empty($request->category_id)  &&  isset($request->category_id)){
                    $streamVideos = StreamVideos::where("status","1")
                    ->where("category_id",$request->category_id)
                    ->get();
                }else{
                    $streamVideos = StreamVideos::get();
                }
                foreach ($streamVideos as $value) {
                    $streamVideosCategory = StreamVideosCategory::where("_id",$value->category_id)
                    ->first();
                    if(!empty($streamVideosCategory->category_name) &&  isset($streamVideosCategory->category_name)){
                        $value->category_name = $streamVideosCategory->category_name;
                    }else{
                        $value->category_name = '';
                    }
                    $data['data'][] = array(
                        '_id' => $value->_id,
                        'thumbnail_image_url'=>$value->thumbnail_image_url,
                        'video_url'=>$value->video_url,
                        'time' => $value->time,
                        'title' => $value->title,
                        'icon_one_url' => $value->icon_one_url,
                        'icon_one_title' => $value->icon_one_title,
                        'icon_two_url' => $value->icon_two_url,
                        'icon_two_title' => $value->icon_two_title,
                        'category_id' => $value->category_id,
                        'category_name' => $value->category_name,
                        'sequence' => $value->sequence,
                        'status' => $value->status,
                        'last_updated_by' => $value->last_updated_by,
                        'created_at' => date("d-M-Y",strtotime($value->created_at)),
                        'updated_at' => date("d-M-Y",strtotime($value->updated_at)),
                    );
                }
                $log_data["StreamVideosCount"] = count($data);
                if (count($data) > 0) { 
                    echo json_encode($data);exit;
                }else{
                    echo "{\"data\":[]}";exit;
                }
            }
            // Stream Videos Category
            $streamVideosCategory = StreamVideosCategory::where("status","1")
            ->get();
            $pageTitle = 'Stream Videos';
            Log::info($log_data);
            return view('MobCMS/stream-videos/index',compact('pageTitle','streamVideosCategory'));
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | index()';
            Log::info($log_data);
            if($request->type  ==  "1"){
                echo "{\"data\":[]}";exit;
            }else{
                $msg = array('message' => Config::get('constants.mob_cms.server_error_500'),'alert-type' => 'error');
                return redirect('/home')->with($msg);
            }
        }
    }

    /**
     * Function create
     * @access  Public
     * @package Stream Videos Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function create(Request $request) {
        try{
            $log_data = $result = [];
            $log_data['function'] = 'create()';
            $log_data['request->all'] = $request->all();
            $validator = Validator::make($request->all(), [
                'video_url' => 'required',
                'time' => 'required',
                'title' => 'required',
                // 'icon_one_url' => 'required',
                // 'icon_one_title' => 'required',
                // 'icon_two_url' => 'required',
                // 'icon_two_title' => 'required',
                'category_id' => 'required',
                'status' => 'required|integer|between:0,5',
                'sequence' => 'required|integer|between:1,1000',
            ]);
            if($validator->fails()) {
                $result['status'] = false;
                $result['message'] = Common::validationErrorsToString($validator->errors());
                Log::info($log_data);
                return response()->json($result);
            }
            if($request->hasFile('image_upload')) {
                $log_data["mediaType"] = $mediaType = 0;
                $mediaName = Str::random(5).time().'.'. $request->image_upload->getClientOriginalExtension();
                $request->image_upload->move((Config::get('constants.module_key.image_upload_path'). '/MobCMS/images'), $mediaName);
                $mediaUrl = url("/")."/".Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
                $filePath = Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
            }else{
                $result['status'] = false;
                $result['message'] = "Image is required";
                Log::info($log_data);
                return response()->json($result);
            }
            $log_data["last_updated_by"] = $last_updated_by = Auth::user()->name;
            $insertedData = array(
                'thumbnail_image_url'=>$mediaUrl,
                'thumbnail_image_file_path'=>$filePath,
                'video_url'=>$request->video_url,
                'time' => $request->time,
                'title' => $request->title,
                'icon_one_url' => $request->icon_one_url,
                'icon_one_title' => $request->icon_one_title,
                'icon_two_url' => $request->icon_two_url,
                'icon_two_title' => $request->icon_two_title,
                'category_id' => $request->category_id,
                'status' => $request->status,
                'sequence' => $request->sequence,
                'status'=>$request['status'],
                'last_updated_by'=>isset($last_updated_by) ? $last_updated_by : 0,
                'created_at'=>date("Y-m-d H:i:s"),
                'updated_at'=>date("Y-m-d H:i:s"),
            );
            $sqlInsertId = StreamVideos::insertGetId($insertedData);
            $log_data["sqlInsertId"] = $sqlInsertId;
            if($sqlInsertId){
                $result['status'] = true;
                $result['message'] = "Record create successfully!";
            }else{
                $result['status'] = false;
                $result['message'] = "Something went wrong!";
            }
            $log_data['result'] = $result;
            Log::info($log_data);
            return response()->json($result);
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | create()';
            $result['status'] = false;
            $result['message'] = Config::get('constants.mob_cms.server_error_500');
            Log::info($log_data);
            return response()->json($result);
        }
    }

    /**
     * Function update
     * @access  Public
     * @package Stream Videos Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function update(Request $request) {
        try{
            $log_data = [];
            $log_data['function'] = 'create()';
            $log_data['request->all'] = $request->all();
            $validator = Validator::make($request->all(), [
                'id' => 'required',
                'video_url' => 'required',
                'time' => 'required',
                'title' => 'required',
                'icon_one_url' => 'required',
                'icon_one_title' => 'required',
                'icon_two_url' => 'required',
                'icon_two_title' => 'required',
                'category_id' => 'required',
                'status' => 'required|integer|between:0,5',
                'sequence' => 'required|integer|between:1,1000',
            ]);
            if($validator->fails()) {
                $result['status'] = false;
                $result['message'] = Common::validationErrorsToString($validator->errors());
                Log::info($log_data);
                return response()->json($result);
            }
            $oldData = StreamVideos::where("_id",$request->id)
            ->first();
            if($request->hasFile('image_upload')) {
                $log_data["mediaType"] = $mediaType = 0;
                $mediaName = Str::random(5).time().'.'. $request->image_upload->getClientOriginalExtension();
                $request->image_upload->move((Config::get('constants.module_key.image_upload_path'). '/MobCMS/images'), $mediaName);
                $mediaUrl = url("/")."/".Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
                $filePath = Config::get('constants.module_key.image_upload_path'). '/MobCMS/images/'.$mediaName;
            }else{
                $mediaUrl = $oldData->thumbnail_image_url;
                $filePath = $oldData->thumbnail_image_file_path;
            }
            $last_updated_by = Auth::user()->name;
            $updateData = array(
                'thumbnail_image_url'=>$mediaUrl,
                'thumbnail_image_file_path'=>$filePath,
                'video_url'=>$request->video_url,
                'time' => $request->time,
                'title' => $request->title,
                'icon_one_url' => $request->icon_one_url,
                'icon_one_title' => $request->icon_one_title,
                'icon_two_url' => $request->icon_two_url,
                'icon_two_title' => $request->icon_two_title,
                'category_id' => $request->category_id,
                'status' => $request->status,
                'sequence' => $request->sequence,
                'last_updated_by'=>isset($last_updated_by) ? $last_updated_by : 0,
                'updated_at'=>date("Y-m-d H:i:s"),
            );
            $sqlUpdate = StreamVideos::where("_id",$request['id'])
            ->update($updateData);
            $log_data["sqlUpdate"] = $sqlUpdate;
            if($sqlUpdate){
                if($oldData->file_path  !=  $filePath){
                    $log_data["fileDeleteStatus"] = Common::deleteFileIfExists($oldData->file_path);
                }
                $result['status'] = true;
                $result['message'] = "Record update successfully!";
            }else{
                $result['status'] = false;
                $result['message'] = "Something went wrong!";
            }
            $log_data['result'] = $result;
            Log::info($log_data);
            return response()->json($result);
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | update()';
            $result['status'] = false;
            $result['message'] = Config::get('constants.mob_cms.server_error_500');
            Log::info($log_data);
            return response()->json($result);
        }
    }

    /**
     * Function delete
     * @access  Public
     * @package Stream Videos Controller
     * @bhagavt
     * @param array
     * @return array
    */
    public function delete(Request $request){
        try{
            $log_data = $result = [];
            $log_data['function'] = 'delete()';
            $log_data['request->all'] = $request->all();
            $validator = Validator::make($request->all(), [
                'uid' => 'required'
            ]);
            if($validator->fails()) {
                $result['status'] = false;
                $result['message'] = Common::validationErrorsToString($validator->errors());
                Log::info($log_data);
                return response()->json($result);
            }
            $filePath = StreamVideos::where('_id', $request->uid)
            ->value("file_path");
            $deleteSql = StreamVideos::where('_id', $request->uid)
            ->delete();
            $log_data['deleteSql'] = $deleteSql;
            if($deleteSql){
                if($filePath){
                    $log_data["filePathDeleteFile"] = Common::deleteFileIfExists($filePath);
                }
                $result['status'] = true;
                $result['message'] = "Record deleted successfully!";
            }else{
                $result['status'] = false;
                $result['message'] = "Something went wrong!";
            }
            $log_data['result'] = $result;
            Log::info($log_data);
            return response()->json($result);
        }catch(\Exception $ex) {
            $log_data['ServiceError'] = 'errorMessage( '.$ex->getMessage().' ) | errorLine( '.$ex->getLine().' ) | errorFile( '.$ex->getFile().' ) | delete()';
            $result['status'] = false;
            $result['message'] = Config::get('constants.mob_cms.server_error_500');
            Log::info($log_data);
            return response()->json($result);
        }
    }
 
}